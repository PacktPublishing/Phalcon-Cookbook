<?php

use Phalcon\Di\FactoryDefault;
use Phalcon\Mvc\View;
use Phalcon\Mvc\View\Engine\Volt as VoltEngine;

$di = new FactoryDefault();

/**
 * Setting up the view component
 */
$di->setShared('view', function () {
    $view = new View();

    $view->setViewsDir('../views/');

    $view->registerEngines([
        '.volt' => function ($view, $di) {
            $volt = new VoltEngine($view, $di);

            $options = [
                'compiledPath'      => '../cache/view/',
                'compiledSeparator' => '_'
            ];

	        $volt->setOptions($options);
	        $volt->getCompiler()->addExtension(new PhpExtension());

            return $volt;
        }
    ]);

    return $view;
});