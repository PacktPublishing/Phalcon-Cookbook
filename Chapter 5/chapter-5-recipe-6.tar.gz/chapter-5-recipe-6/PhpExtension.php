<?php

class PhpExtension
{
    /**
     * Try to compile native php function
     *
     * Invoked before any attempt to compile a function call in any template.
     *
     * @param string $name
     * @param mixed $arguments
     * @return string
     */
    public function compileFunction($name, $arguments = null)
    {
        if (function_exists($name)) {
            if (func_num_args() > 1) {
                $arguments = array_slice(func_get_args(), 1);
                return $name . '(' . $arguments[0] . ')';
            } else {
                return $name . '()';
            }
        }
    }
}
