CREATE TABLE `robots` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(70) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(32) COLLATE utf8_unicode_ci NOT NULL default 'mechanical',
  `year` int(11) NOT NULL default 1900,
  `datetime` datetime NOT NULL,
  `text` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `robots` VALUES
  (1,'Robotina','mechanical',1972,'1972/01/01 00:00:00','text'),
  (2,'Astro Boy','mechanical',1952,'1952/01/01 00:00:00','text'),
  (2,'Astro Boy','virtual',1952,'1952/01/01 00:00:00','text'),
  (3,'Terminator','cyborg',2029,'2029/01/01 00:00:00','text');

CREATE TABLE `parts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(70) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `parts` VALUES (1,'Head'),(2,'Body'),(3,'Arms'),(4,'Legs'),(5,'CPU');

CREATE TABLE `robots_parts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `robots_id` int(10) unsigned NOT NULL,
  `parts_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `robots_id` (`robots_id`),
  KEY `parts_id` (`parts_id`),
  CONSTRAINT `robots_parts_ibfk_1` FOREIGN KEY (`robots_id`) REFERENCES `robots` (`id`),
  CONSTRAINT `robots_parts_ibfk_2` FOREIGN KEY (`parts_id`) REFERENCES `parts` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `robots_parts` VALUES (1,1,1),(2,1,2),(3,1,3);
