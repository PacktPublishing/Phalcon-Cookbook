<?php

use Phalcon\Mvc\Model\Criteria;
use Phalcon\Paginator\Adapter\Model as Paginator;


class RobotsController extends ControllerBase
{
    /**
     * Index action
     */
    public function indexAction()
    {
        $this->persistent->parameters = null;
    }

    /**
     * Index action
     */
    public function listAction()
    {
        $robots = Robots::find();

        $this->view->setVars(
            [
                'robots'    => $robots,
                'date_time' => strtotime(date('Y-m-d H:i:s'))
            ]
        );
    }

    /**
     * Searches for robots
     */
    public function searchAction()
    {
        $numberPage = 1;
        if ($this->request->isPost()) {
            $query = Criteria::fromInput($this->di, 'Robots', $_POST);
            $this->persistent->parameters = $query->getParams();
        } else {
            $numberPage = $this->request->getQuery("page", "int");
        }

        $parameters = $this->persistent->parameters;
        if (!is_array($parameters)) {
            $parameters = array();
        }
        $parameters["order"] = "id";

        $robots = Robots::find($parameters);
        if (count($robots) == 0) {
            $this->flash->notice("The search did not find any robots");

            return $this->dispatcher->forward(array(
                "controller" => "robots",
                "action" => "index"
            ));
        }

        $paginator = new Paginator(array(
            "data" => $robots,
            "limit"=> 10,
            "page" => $numberPage
        ));

        $this->view->page = $paginator->getPaginate();
    }

    /**
     * Displays the creation form
     */
    public function newAction()
    {

    }

    /**
     * Edits a robot
     *
     * @param string $id
     */
    public function editAction($id)
    {
        if (!$this->request->isPost()) {

            $robot = Robots::findFirstByid($id);
            if (!$robot) {
                $this->flash->error("robot was not found");

                return $this->dispatcher->forward(array(
                    "controller" => "robots",
                    "action" => "index"
                ));
            }

            $this->view->id = $robot->id;

            $this->tag->setDefault("id", $robot->id);
            $this->tag->setDefault("name", $robot->name);
            $this->tag->setDefault("type", $robot->type);
            $this->tag->setDefault("year", $robot->year);
            $this->tag->setDefault("datetime", $robot->datetime);
            $this->tag->setDefault("text", $robot->text);

        }
    }

    /**
     * Creates a new robot
     */
    public function createAction()
    {
        if (!$this->request->isPost()) {
            return $this->dispatcher->forward(array(
                "controller" => "robots",
                "action" => "index"
            ));
        }

        $robot = new Robots();

        $robot->name = $this->request->getPost("name");
        $robot->type = $this->request->getPost("type");
        $robot->year = $this->request->getPost("year");
        $robot->datetime = $this->request->getPost("datetime");
        $robot->text = $this->request->getPost("text");


        if (!$robot->save()) {
            foreach ($robot->getMessages() as $message) {
                $this->flash->error($message);
            }

            return $this->dispatcher->forward(array(
                "controller" => "robots",
                "action" => "new"
            ));
        }

        $this->flash->success("robot was created successfully");

        return $this->dispatcher->forward(array(
            "controller" => "robots",
            "action" => "index"
        ));
    }

    /**
     * Saves a robot edited
     *
     */
    public function saveAction()
    {

        if (!$this->request->isPost()) {
            return $this->dispatcher->forward(array(
                "controller" => "robots",
                "action" => "index"
            ));
        }

        $id = $this->request->getPost("id");

        $robot = Robots::findFirstByid($id);
        if (!$robot) {
            $this->flash->error("robot does not exist " . $id);

            return $this->dispatcher->forward(array(
                "controller" => "robots",
                "action" => "index"
            ));
        }

        $robot->name = $this->request->getPost("name");
        $robot->type = $this->request->getPost("type");
        $robot->year = $this->request->getPost("year");
        $robot->datetime = $this->request->getPost("datetime");
        $robot->text = $this->request->getPost("text");


        if (!$robot->save()) {

            foreach ($robot->getMessages() as $message) {
                $this->flash->error($message);
            }

            return $this->dispatcher->forward(array(
                "controller" => "robots",
                "action" => "edit",
                "params" => array($robot->id)
            ));
        }

        $this->flash->success("robot was updated successfully");

        return $this->dispatcher->forward(array(
            "controller" => "robots",
            "action" => "index"
        ));
    }

    /**
     * Deletes a robot
     *
     * @param string $id
     */
    public function deleteAction($id)
    {
        $robot = Robots::findFirstByid($id);
        if (!$robot) {
            $this->flash->error("robot was not found");

            return $this->dispatcher->forward(array(
                "controller" => "robots",
                "action" => "index"
            ));
        }

        if (!$robot->delete()) {

            foreach ($robot->getMessages() as $message) {
                $this->flash->error($message);
            }

            return $this->dispatcher->forward(array(
                "controller" => "robots",
                "action" => "search"
            ));
        }

        $this->flash->success("robot was deleted successfully");

        return $this->dispatcher->forward(array(
            "controller" => "robots",
            "action" => "index"
        ));
    }

}
