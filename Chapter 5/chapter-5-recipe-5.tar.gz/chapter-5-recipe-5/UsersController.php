<?php

class UsersController extends \Phalcon\Mvc\Controller
{
    public function listAction()
    {
        $users = [
            [
                'id'         => 1,
                'email'      => 'john@doe.com',
                'first_name' => 'John',
                'last_name'  => 'Doe',
                'created_at' => date("Y-m-d H:i:s", mt_rand(1262055681, time()))
            ],
            [
                'id'         => 2,
                'email'      => 'john@doe.com',
                'first_name' => 'John',
                'last_name'  => 'Doe',
                'created_at' => date("Y-m-d H:i:s", mt_rand(1262055681, time()))
            ],
            [
                'id'         => 3,
                'email'      => 'john@doe.com',
                'first_name' => 'John',
                'last_name'  => 'Doe',
                'created_at' => date("Y-m-d H:i:s", mt_rand(1262055681, time()))
            ],
            [
                'id'         => 4,
                'email'      => 'john@doe.com',
                'first_name' => 'John',
                'last_name'  => 'Doe',
                'created_at' => date("Y-m-d H:i:s", mt_rand(1262055681, time()))
            ],
            [
                'id'         => 5,
                'email'      => 'john@doe.com',
                'first_name' => 'John',
                'last_name'  => 'Doe',
                'created_at' => date("Y-m-d H:i:s", mt_rand(1262055681, time()))
            ],
            [
                'id'         => 6,
                'email'      => 'john@doe.com',
                'first_name' => 'John',
                'last_name'  => 'Doe',
                'created_at' => date("Y-m-d H:i:s", mt_rand(1262055681, time()))
            ],
        ];

        $this->view->setVar('users', json_decode(json_encode($users)));
    }
}