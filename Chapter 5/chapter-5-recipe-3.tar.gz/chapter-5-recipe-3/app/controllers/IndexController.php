<?php

class IndexController extends ControllerBase
{
    public function indexAction()
    {
        $user = (object) ['name' => 'John Doe'];

        $this->view->setVar('user', $user);
        //$this->view->setVar('user', null);
    }
}

