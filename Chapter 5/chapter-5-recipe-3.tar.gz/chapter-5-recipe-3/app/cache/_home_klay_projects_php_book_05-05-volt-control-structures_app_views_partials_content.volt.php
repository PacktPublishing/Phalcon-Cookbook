<?php if (!isset($user)) { ?>
    <div class="col-md-4 col-md-offset-4">
        <form class="form-signin">
            <h2 class="form-signin-heading">Please sign in</h2>
            <input type="email" class="form-control" id="inputEmail"><br>
            <input type="password" class="form-control" id="inputPassword">
            <div class="checkbox">
                <label>
                    <input type="checkbox" value="remember-me"> Remember me
                </label>
            </div>
            <button type="submit" class="btn btn-lg btn-primary btn-block">Sign in</button>
        </form>
    </div>
<?php } else { ?>
    <div class="page-header">
        <h1>Welcome!</h1>
        <p>Hello <?php echo $user->name; ?></p>
        <p>We are happy to see you again</p>
    </div>
<?php } ?>
