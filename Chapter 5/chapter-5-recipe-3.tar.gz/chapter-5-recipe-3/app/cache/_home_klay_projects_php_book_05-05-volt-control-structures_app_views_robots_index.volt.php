<div class="page-header">
    <h1>
        Search robots
    </h1>
    <p>
        <?php echo $this->tag->linkTo(array('robots/new', 'Create robots')); ?>
    </p>
</div>

<?php echo $this->getContent(); ?>

<?php echo $this->tag->form(array('robots/search', 'method' => 'post', 'autocomplete' => 'off', 'class' => 'form-horizontal')); ?>

<div class="form-group">
    <label for="fieldId" class="col-sm-2 control-label">Id</label>
    <div class="col-sm-10">
        <?php echo $this->tag->textField(array('id', 'type' => 'numeric', 'class' => 'form-control', 'id' => 'fieldId')); ?>
    </div>
</div>

<div class="form-group">
    <label for="fieldName" class="col-sm-2 control-label">Name</label>
    <div class="col-sm-10">
        <?php echo $this->tag->textField(array('name', 'size' => 30, 'class' => 'form-control', 'id' => 'fieldName')); ?>
    </div>
</div>

<div class="form-group">
    <label for="fieldType" class="col-sm-2 control-label">Type</label>
    <div class="col-sm-10">
        <?php echo $this->tag->textField(array('type', 'size' => 30, 'class' => 'form-control', 'id' => 'fieldType')); ?>
    </div>
</div>

<div class="form-group">
    <label for="fieldYear" class="col-sm-2 control-label">Year</label>
    <div class="col-sm-10">
        <?php echo $this->tag->textField(array('year', 'type' => 'numeric', 'class' => 'form-control', 'id' => 'fieldYear')); ?>
    </div>
</div>

<div class="form-group">
    <label for="fieldDatetime" class="col-sm-2 control-label">Datetime</label>
    <div class="col-sm-10">
        <?php echo $this->tag->textField(array('datetime', 'size' => 30, 'class' => 'form-control', 'id' => 'fieldDatetime')); ?>
    </div>
</div>

<div class="form-group">
    <label for="fieldText" class="col-sm-2 control-label">Text</label>
    <div class="col-sm-10">
        <?php echo $this->tag->textArea(array('text', 'cols' => '30', 'rows' => '4', 'class' => 'form-control', 'id' => 'fieldText')); ?>
    </div>
</div>


<div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
        <?php echo $this->tag->submitButton(array('Search', 'class' => 'btn btn-default')); ?>
    </div>
</div>

</form>
