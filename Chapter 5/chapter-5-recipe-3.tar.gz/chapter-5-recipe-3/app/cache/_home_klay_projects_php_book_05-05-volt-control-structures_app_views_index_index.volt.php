
    <?php $this->partial('partials/menu', array('user' => $user)); ?>



    <?php $this->partial('partials/content', array('user' => $user)); ?>

