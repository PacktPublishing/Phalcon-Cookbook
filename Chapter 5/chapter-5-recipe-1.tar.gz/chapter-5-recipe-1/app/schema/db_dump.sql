CREATE TABLE `customers` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(64) NULL DEFAULT '',
  `email` VARCHAR(255) NOT NULL,
  `address` VARCHAR(255) NULL DEFAULT '',
  `city` VARCHAR(128) NULL DEFAULT '',
  `country` VARCHAR(128) NULL DEFAULT '',
  `postalcode` MEDIUMINT UNSIGNED DEFAULT 0,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `customers_email` (`email`),
  KEY `customers_phone` (`city`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;

INSERT INTO `customers` VALUES
  (1, 'Wartian Herkku', 'wartian@herkku.com','Torikatu 38', 'Oulu', 'Finland', 90110),
  (2, 'Wellington Importadora', 'i@wellington.com','Rua do Mercado, 12', 'Resende', 'Brazil', 8737363),
  (3, 'White Clover Markets', 'white@clover.com','305 - 14th Ave. S. Suite 3B', 'Seattle', 'USA', 98128),
  (4, 'Wilman Kala', 'kala@wilman.com','Keskuskatu 45', 'Helsinki', 'Finland', 21240),
  (5, 'Wolski', 'wolski@gmail.com','ul. Filtrowa 68', 'Walla', 'Poland', 1012);

CREATE TABLE `orders` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `customer_id` INT(11) UNSIGNED NOT NULL NULL,
  `status` ENUM('open', 'closed') NOT NULL DEFAULT 'open',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `sum` DECIMAL(10,2) NOT NULL DEFAULT '0.0',
  PRIMARY KEY (`id`),
  KEY `orders_customer_id` (`customer_id`),
  KEY `orders_created_at` (`created_at`),
  CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `orders` VALUES
  (1, 1, 'open','2016-01-11 00:00:01', 157.3),
  (2, 1, 'closed','2016-11-01 00:00:01', 57.3),
  (3, 1, 'open','2016-02-12 00:00:01', 100),
  (4, 1, 'closed','2016-12-02 00:00:01', 5.3),
  (5, 1, 'open','2016-03-03 00:00:01', 70.4),
  (6, 2, 'closed','2016-04-04 00:00:01', 11.0),
  (7, 2, 'closed','2016-02-04 00:00:01', 12.0),
  (8, 2, 'open','2016-03-05 00:00:01', 200.0),
  (9, 2, 'closed','2016-04-02 00:00:01', 33.22),
  (10, 2, 'open','2016-07-07 00:00:01', 44.42),
  (11, 3, 'closed','2016-03-08 00:00:01', 145.90),
  (12, 3, 'closed','2016-02-09 00:00:01', 11.93),
  (13, 3, 'closed','2016-09-01 00:00:01', 22.0),
  (14, 3, 'closed','2016-01-01 00:00:01', 234.0),
  (15, 3, 'closed','2016-05-05 00:00:01', 345.0),
  (16, 3, 'open','2016-08-03 00:00:01', 193.72),
  (17, 5, 'closed','2016-07-06 00:00:01', 66.77),
  (18, 5, 'closed','2016-10-10 00:00:01', 77.66),
  (19, 5, 'closed','2016-10-01 00:00:01', 222.33),
  (20, 5, 'open','2016-10-10 00:00:01', 90.0);
