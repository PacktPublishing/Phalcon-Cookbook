<div class="row center-block">
    <?php echo $this->getContent(); ?>
</div>