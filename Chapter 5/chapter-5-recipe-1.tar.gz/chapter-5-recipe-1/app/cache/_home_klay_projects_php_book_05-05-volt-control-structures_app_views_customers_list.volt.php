<div class="page-header">
    <h1>
        Customers' Orders
    </h1>
</div>

<?php echo $this->getContent(); ?>

<div class="container">
    <div class="col-md-3">
        <div class="form-group">
            <label for="customers">Select Customer</label>
            <?php echo $this->tag->select(array('customer', $customers, 'using' => array('id', 'name'), 'useEmpty' => true, 'emptyText' => 'Please select', 'id' => 'customers')); ?>
        </div>
    </div>
    <div class="col-md-9">
        <div id="orders">
            &nbsp;
        </div>
    </div>
</div>

<script
        type="application/javascript"
        src="https://code.jquery.com/jquery-2.1.4.min.js">
</script>
<script type="application/javascript">
    $("#customers").change(function() {
        var value = $(this).val();
        if ($.isNumeric( value )) {
            var getOrdersUrl = "<?php echo $getOrdersUrl; ?>";

            $.ajax({
                type: "POST",
                url: getOrdersUrl,
                data: {"id": value},
                success: function(response){
                    $("#orders").html( response );
                }
            });
        }
    });
</script>
