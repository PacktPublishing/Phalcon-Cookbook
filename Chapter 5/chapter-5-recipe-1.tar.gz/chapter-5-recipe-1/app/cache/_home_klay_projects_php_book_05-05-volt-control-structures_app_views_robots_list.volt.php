<div class="page-header">
    <h1>
        List robots
    </h1>
    <p>
        <?php echo $this->tag->linkTo(array('robots/new', 'Create robots')); ?>
    </p>
</div>

<?php echo $this->getContent(); ?>

<div class="container">
<?php $v10697388861257429611iterator = $robots; $v10697388861257429611incr = 0; $v10697388861257429611loop = new stdClass(); $v10697388861257429611loop->length = count($v10697388861257429611iterator); $v10697388861257429611loop->index = 1; $v10697388861257429611loop->index0 = 1; $v10697388861257429611loop->revindex = $v10697388861257429611loop->length; $v10697388861257429611loop->revindex0 = $v10697388861257429611loop->length - 1; ?><?php foreach ($v10697388861257429611iterator as $robot) { ?><?php $v10697388861257429611loop->first = ($v10697388861257429611incr == 0); $v10697388861257429611loop->index = $v10697388861257429611incr + 1; $v10697388861257429611loop->index0 = $v10697388861257429611incr; $v10697388861257429611loop->revindex = $v10697388861257429611loop->length - $v10697388861257429611incr; $v10697388861257429611loop->revindex0 = $v10697388861257429611loop->length - ($v10697388861257429611incr + 1); $v10697388861257429611loop->last = ($v10697388861257429611incr == ($v10697388861257429611loop->length - 1)); ?>
    <?php if ($v10697388861257429611loop->first) { ?>
        <table class="table table-striped">
        <tr>
            <th>#</th>
            <th>Id</th>
            <th>Name</th>
            <th>Type</th>
            <th>Parts</th>
        </tr>
    <?php } ?>
    <?php if ($robot->type == 'cyborg') { ?>
        <tr class="danger">
    <?php } else { ?>
        <tr>
    <?php } ?>
        <td><?php echo $v10697388861257429611loop->index; ?></td>
        <td><?php echo $robot->id; ?></td>
        <td>
            <h5>
                <?php if (date('Y', $date_time) < $robot->year) { ?>
                    New
                <?php } else { ?>
                    Classic
                <?php } ?>
                <?php echo $robot->name; ?>
            </h5>
        </td>
        <td>
            <?php echo $robot->type; ?>
        </td>
        <td>
            <?php $v10697388861257429612iterated = false; ?><?php foreach ($robot->RobotsParts as $robot_part) { ?><?php $v10697388861257429612iterated = true; ?>
                <span class="label label-default">
                    <?php echo $this->escaper->escapeHtml($robot_part->Parts->name); ?>
                </span>&nbsp;
            <?php } if (!$v10697388861257429612iterated) { ?>
                There are no parts to show
            <?php } ?>
        </td>
    </tr>
    <?php if ($v10697388861257429611loop->last) { ?>
        </table>
    <?php } ?>
<?php $v10697388861257429611incr++; } ?>
</div>
