<div class="page-header">
    <h1>
        Search customers
    </h1>
    <p>
        <?php echo $this->tag->linkTo(array('customers/new', 'Create customers')); ?>
    </p>
</div>

<?php echo $this->getContent(); ?>

<?php echo $this->tag->form(array('customers/search', 'method' => 'post', 'autocomplete' => 'off', 'class' => 'form-horizontal')); ?>

<div class="form-group">
    <label for="fieldId" class="col-sm-2 control-label">Id</label>
    <div class="col-sm-10">
        <?php echo $this->tag->textField(array('id', 'type' => 'numeric', 'class' => 'form-control', 'id' => 'fieldId')); ?>
    </div>
</div>

<div class="form-group">
    <label for="fieldName" class="col-sm-2 control-label">Name</label>
    <div class="col-sm-10">
        <?php echo $this->tag->textField(array('name', 'size' => 30, 'class' => 'form-control', 'id' => 'fieldName')); ?>
    </div>
</div>

<div class="form-group">
    <label for="fieldEmail" class="col-sm-2 control-label">Email</label>
    <div class="col-sm-10">
        <?php echo $this->tag->textField(array('email', 'size' => 30, 'class' => 'form-control', 'id' => 'fieldEmail')); ?>
    </div>
</div>

<div class="form-group">
    <label for="fieldAddress" class="col-sm-2 control-label">Address</label>
    <div class="col-sm-10">
        <?php echo $this->tag->textField(array('address', 'size' => 30, 'class' => 'form-control', 'id' => 'fieldAddress')); ?>
    </div>
</div>

<div class="form-group">
    <label for="fieldCity" class="col-sm-2 control-label">City</label>
    <div class="col-sm-10">
        <?php echo $this->tag->textField(array('city', 'size' => 30, 'class' => 'form-control', 'id' => 'fieldCity')); ?>
    </div>
</div>

<div class="form-group">
    <label for="fieldCountry" class="col-sm-2 control-label">Country</label>
    <div class="col-sm-10">
        <?php echo $this->tag->textField(array('country', 'size' => 30, 'class' => 'form-control', 'id' => 'fieldCountry')); ?>
    </div>
</div>

<div class="form-group">
    <label for="fieldPostalcode" class="col-sm-2 control-label">Postalcode</label>
    <div class="col-sm-10">
        <?php echo $this->tag->textField(array('postalcode', 'type' => 'numeric', 'class' => 'form-control', 'id' => 'fieldPostalcode')); ?>
    </div>
</div>


<div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
        <?php echo $this->tag->submitButton(array('Search', 'class' => 'btn btn-default')); ?>
    </div>
</div>

</form>
