<div class="list-group">
    <?php $v168988633631048809591iterated = false; ?><?php foreach ($customer->Orders as $order) { ?><?php $v168988633631048809591iterated = true; ?>
        <a href="#" class="list-group-item active">
            <h4 class="list-group-item-heading">
                Order # <?php echo $order->id; ?>
            </h4>
        </a>
        <a href="#" class="list-group-item">
            <h4 class="list-group-item-heading">
                Content:
            </h4>
            <p class="list-group-item-text">
                Status: <?php echo $order->status; ?>  <br>
                Date: <?php echo $order->created_at; ?>  <br>
                Sum: <?php echo $order->sum; ?> $  <br>
            </p>
        </a>
    <?php } if (!$v168988633631048809591iterated) { ?>
        <a href="#" class="list-group-item active">
            <h4 class="list-group-item-heading">
                No orders
            </h4>
        </a>
    <?php } ?>
</div>
