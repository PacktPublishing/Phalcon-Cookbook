<?php

class SessionController extends extends \Phalcon\Mvc\Controller
{
    public function onConstruct()
    {
        $this->view->setMainView('session');
    }
}