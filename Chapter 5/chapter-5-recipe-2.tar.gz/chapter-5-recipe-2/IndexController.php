<?php

class IndexController extends extends \Phalcon\Mvc\Controller
{
    public function onConstruct()
    {
        $this->view->setMainView('main');
    }
}