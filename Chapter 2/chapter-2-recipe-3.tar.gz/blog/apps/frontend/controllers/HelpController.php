<?php

namespace Blog\Frontend\Controllers;

class HelpController extends ControllerBase
{

    public function indexAction()
    {

    }

}

