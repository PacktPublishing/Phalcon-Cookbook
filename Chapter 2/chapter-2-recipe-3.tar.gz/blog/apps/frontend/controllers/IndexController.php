<?php

namespace Blog\Frontend\Controllers;

use Phalcon\Mvc\Model\Criteria;

class IndexController extends ControllerBase
{

    public function indexAction()
    {

    }

}

