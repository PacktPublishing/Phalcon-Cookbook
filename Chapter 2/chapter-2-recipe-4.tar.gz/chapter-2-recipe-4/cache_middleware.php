<?php

use Phalcon\Mvc\Micro\MiddlewareInterface;

class CacheMiddleware implements MiddlewareInterface
{
    public function call($application)
    {
        $cache   = $application['cache'];
        $session = $application['session'];

        if (!$this->session->has("user-auth")) {
            if ($cache->exists($key)) {
                echo $cache->get($key);

                return false;
            }
        }

        return true;
    }
}


