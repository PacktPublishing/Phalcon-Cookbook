<?php

$app = new Phalcon\Mvc\Micro();

// Executed before every route is executed
// Return false cancels the route execution
$app->before(function () use ($app) {
  if ($app['session']->get('auth') == false) {
      // Redirect the user to the '/login' route
      $app['response']->redirect("/login"); 

      // Return false stops the normal execution
      return false;
  }

  return true;
});