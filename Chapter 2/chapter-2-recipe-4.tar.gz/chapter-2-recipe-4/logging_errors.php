<?php

use Phalcon\Events\Event;
use Phalcon\Mvc\User\Plugin;
use Phalcon\Dispatcher;
use Phalcon\Mvc\Dispatcher\Exception as DispatcherException;
use Phalcon\Mvc\Dispatcher as MvcDispatcher;


class BugsCatcher extends Plugin
{
    /**
     * This action is executed before execute any action in the application
     *
     * @param Event $event
     * @param MvcDispatcher $dispatcher
     * @param \Exception $exception
     * @return boolean
     */
    public function beforeException(Event $event, MvcDispatcher $dispatcher, \Exception $exception)
    {
        $code    = $exception->getCode();
        $message = $exception->getMessage();
        $file    = $exception->getFile();
        $line    = $exception->getLine();
        $trace   = $exception->getTraceAsString();
        $date    = date('Y-m-d H:i:s');

        $body = <<<TEXT
<h1>Error</h1>
<p><em>$date</em></p>
<p>An error was detected in file $file on line $line.</p>

<p>System message: $message</p>
<p>Backtrace:</p>
<pre>$trace</pre>
TEXT;


        mail('alerts@mycompany.com', "Error: {$code}", $body);

        error_log($exception->getMessage() . PHP_EOL . $exception->getTraceAsString());

        if ($exception instanceof DispatcherException) {

            switch ($exception->getCode()) {
                case Dispatcher::EXCEPTION_HANDLER_NOT_FOUND:
                case Dispatcher::EXCEPTION_ACTION_NOT_FOUND:
                    $dispatcher->forward(
                        [
                            'controller' => 'errors',
                            'action'     => 'show404'
                        ]
                    );
                    return false;
            }
        }

        $dispatcher->forward(
            [
                'controller' => 'errors',
                'action'     => 'show500'
            ]
        );
        return false;
    }
}
