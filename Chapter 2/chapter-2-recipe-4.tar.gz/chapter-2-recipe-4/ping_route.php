<?php

namespace PhalconDemo\Plugins;

use Phalcon\Mvc\User\Plugin;

class Status extends Plugin
{
    protected $statusCode;
    protected $statusReport;

    public function __construct()
    {
        // Some checks and data collection
        // ..

        $this->statusCode = ...
        $this->statusReport = ...
    }

    public function getStatusCode()
    {
        return $this->statusCode;
    }

    public function getStatusReport()
    {
        return $this->statusCode;
    }
}

// Return status if the /ping route is matched
$router->add('/ping', [])->match(function () {
    $status = new Staus;

    $responseCode = $status->getStatusCode();
    $responseData = $status->getStatusReport();

    $response = $this->getResponse();

    $response->setStatusCode($responseCode);
    $response->setJsonContent($responseData);

    $response->send();
});