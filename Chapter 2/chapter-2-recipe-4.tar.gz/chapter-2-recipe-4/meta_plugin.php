<?php

use Phalcon\Mvc\User\Plugin;

class Meta extends Plugin
{
    public function keywords($postId)
    {
        // Method's logic

        echo '<meta name="keywords" content="' . implode(',', $keywords) . '">';
    }

    public function description($postId)
    {
        // Method's logic ...

        echo '<meta name="description" content="' . $description . '">';
    }
}