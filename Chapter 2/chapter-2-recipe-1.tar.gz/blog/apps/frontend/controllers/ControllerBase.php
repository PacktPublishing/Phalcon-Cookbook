<?php

namespace Blog\Frontend\Controllers;

use Phalcon\Mvc\Controller;

class ControllerBase extends Controller
{

}
