<?php

class JaController extends LanguageController
{
    public function indexAction()
    {
    }

    public function contactsAction()
    {
        var_dump(__CLASS__, __METHOD__, $_SERVER, func_get_args());die;
    }
}
