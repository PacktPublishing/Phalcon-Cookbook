<?php

abstract class LanguageController extends ControllerBase
{
    public function onConstruct()
    {
        $params  = $this->dispatcher->getParams();
        $action = 'index';

        // Translate article here
        $translate = [
            '連絡先'    => 'contacts',
            'contacts' => 'contacts',
        ];

        if (isset($translate[$params['article']])) {
            $action = $translate[$params['article']];
        }

        $this->dispatcher->forward([
            'controller' => $params['lang'],
            'action'     => $action
        ]);

        return;
    }
}
