<?php

use Phalcon\Mvc\Model;

class Posts extends Model
{
    public $id;
    public $title;
    public $body;
    public $teaser;

    public function getSource()
    {
        return 'posts';
    }

    public static function find($parameters = null)
    {
        return parent::find($parameters);
    }

    public static function findFirst($parameters = null)
    {
        return parent::findFirst($parameters);
    }

    public function afterSave()
    {
        $this->clearCache();
    }

    public function afterDelete()
    {
        $this->clearCache();
    }

    public function clearCache()
    {
        if ($this->id) {
            $viewCache = $this->getDI()->getShared('viewCache');
            $viewCache->delete('post-' . $this->id);
        }
    }
}
