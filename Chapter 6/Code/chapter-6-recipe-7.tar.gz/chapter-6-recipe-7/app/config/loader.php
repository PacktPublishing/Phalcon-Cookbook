<?php

use Phalcon\Loader;

$loader = new Loader();
$dirs = [
    $config->application->controllersDir,
    $config->application->modelsDir
];

$loader->registerDirs($dirs);
$loader->register();
