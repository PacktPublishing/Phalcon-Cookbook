<?php

use Phalcon\Mvc\Model\Criteria;
use Phalcon\Paginator\Adapter\Model as Paginator;


class SnippetsController extends ControllerBase
{
    /**
     * Index action
     */
    public function indexAction()
    {
        $this->persistent->parameters = null;
    }

    /**
     * Searches for snippets
     */
    public function searchAction()
    {
        $numberPage = 1;
        if ($this->request->isPost()) {
            $query = Criteria::fromInput($this->di, 'Snippets', $_POST);
            $this->persistent->parameters = $query->getParams();
        } else {
            $numberPage = $this->request->getQuery("page", "int");
        }

        $parameters = $this->persistent->parameters;
        if (!is_array($parameters)) {
            $parameters = array();
        }
        $parameters["order"] = "id";

        $snippets = Snippets::find($parameters);
        if (count($snippets) == 0) {
            $this->flash->notice("The search did not find any snippets");

            $this->dispatcher->forward(array(
                "controller" => "snippets",
                "action" => "index"
            ));

            return;
        }

        $paginator = new Paginator(array(
            'data' => $snippets,
            'limit'=> 10,
            'page' => $numberPage
        ));

        $this->view->page = $paginator->getPaginate();
    }

    /**
     * Displays the creation form
     */
    public function newAction()
    {

    }

    /**
     * Edits a snippet
     *
     * @param string $id
     */
    public function editAction($id)
    {
        if (!$this->request->isPost()) {

            $snippet = Snippets::findFirstByid($id);
            if (!$snippet) {
                $this->flash->error("snippet was not found");

                $this->dispatcher->forward(array(
                    'controller' => "snippets",
                    'action' => 'index'
                ));

                return;
            }

            $this->view->id = $snippet->id;

            $this->tag->setDefault("id", $snippet->id);
            $this->tag->setDefault("user_id", $snippet->user_id);
            $this->tag->setDefault("title", $snippet->title);
            $this->tag->setDefault("body", $snippet->body);
            $this->tag->setDefault("created_at", $snippet->created_at);

        }
    }

    /**
     * Creates a new snippet
     */
    public function createAction()
    {
        if (!$this->request->isPost()) {
            $this->dispatcher->forward(array(
                'controller' => "snippets",
                'action' => 'index'
            ));

            return;
        }

        $snippet = new Snippets();
        $snippet->user_id = $this->request->getPost("user_id");
        $snippet->title = $this->request->getPost("title");
        $snippet->body = $this->request->getPost("body");
        $snippet->created_at = $this->request->getPost("created_at");


        if (!$snippet->save()) {
            foreach ($snippet->getMessages() as $message) {
                $this->flash->error($message);
            }

            $this->dispatcher->forward(array(
                'controller' => "snippets",
                'action' => 'new'
            ));

            return;
        }

        $this->flash->success("snippet was created successfully");

        $this->dispatcher->forward(array(
            'controller' => "snippets",
            'action' => 'index'
        ));
    }

    /**
     * Saves a snippet edited
     *
     */
    public function saveAction()
    {

        if (!$this->request->isPost()) {
            $this->dispatcher->forward(array(
                'controller' => "snippets",
                'action' => 'index'
            ));

            return;
        }

        $this->session->set('userId', 1);

        $id = $this->request->getPost("id");
        $snippet = Snippets::findFirstByid($id);

        if (!$snippet) {
            $this->flash->error("snippet does not exist " . $id);

            $this->dispatcher->forward(array(
                'controller' => "snippets",
                'action' => 'index'
            ));

            return;
        }

        $snippet->user_id = $this->request->getPost("user_id");
        $snippet->title = $this->request->getPost("title");
        $snippet->body = $this->request->getPost("body");
        $snippet->created_at = $this->request->getPost("created_at");


        if (!$snippet->save()) {

            foreach ($snippet->getMessages() as $message) {
                $this->flash->error($message);
            }

            $this->dispatcher->forward(array(
                'controller' => "snippets",
                'action' => 'edit',
                'params' => array($snippet->id)
            ));

            return;
        }

        $this->flash->success("snippet was updated successfully");

        $this->dispatcher->forward(array(
            'controller' => "snippets",
            'action' => 'index'
        ));
    }

    /**
     * Deletes a snippet
     *
     * @param string $id
     */
    public function deleteAction($id)
    {
        $snippet = Snippets::findFirstByid($id);
        if (!$snippet) {
            $this->flash->error("snippet was not found");

            $this->dispatcher->forward(array(
                'controller' => "snippets",
                'action' => 'index'
            ));

            return;
        }

        if (!$snippet->delete()) {

            foreach ($snippet->getMessages() as $message) {
                $this->flash->error($message);
            }

            $this->dispatcher->forward(array(
                'controller' => "snippets",
                'action' => 'search'
            ));

            return;
        }

        $this->flash->success("snippet was deleted successfully");

        $this->dispatcher->forward(array(
            'controller' => "snippets",
            'action' => "index"
        ));
    }

}
