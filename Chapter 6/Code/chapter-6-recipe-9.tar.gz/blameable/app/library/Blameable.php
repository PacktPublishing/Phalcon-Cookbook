<?php

use Phalcon\Mvc\ModelInterface;
use Phalcon\Mvc\Model\Behavior;
use Phalcon\Mvc\Model\BehaviorInterface;

class Blameable extends Behavior implements BehaviorInterface
{
    public function notify($eventType, ModelInterface $model)
    {
        if ($eventType == 'afterUpdate') {
            return $this->auditAfterUpdate($model);
        }

        return null;
    }

    public function auditAfterUpdate(ModelInterface $model)
    {
        $changedFields = $model->getChangedFields();
        $session = $model->getDI()->getSession();

        if (!$session->has('userId')) {
            return null;
        }

        if (count($changedFields)) {
            $audit = new Audits();

            $request = $model->getDI()->getRequest();

            $audit->user_id = $session->get('userId');
            $audit->model_name = get_class($model);
            $audit->ip_address = ip2long($request->getClientAddress());
            $audit->type = Audits::TYPE_UPDATE;

            $audit->save();

            $originalData = $model->getSnapshotData();
            foreach ($changedFields as $field) {
                $auditDetail = new AuditDetails();

                $auditDetail->audit_id = $audit->id;
                $auditDetail->field_name = $field;
                $auditDetail->old_value = $originalData[$field];
                $auditDetail->new_value = $model->$field;
                $auditDetail->save();
            }

            return true;
        }

        return null;
    }
}
