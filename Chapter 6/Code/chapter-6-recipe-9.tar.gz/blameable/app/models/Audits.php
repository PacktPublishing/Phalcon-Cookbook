<?php

use Phalcon\Mvc\Model;

/**
 * @property \Phalcon\Mvc\Model\Resultset\Simple details
 */
class Audits extends Model
{
    const TYPE_CREATE = 'C';
    const TYPE_UPDATE = 'U';

    public $id;
    public $user_id;
    public $model_name;
    public $ip_address;
    public $type;
    public $created_at;

    public function initialize()
    {
        $this->hasMany('id', 'AuditDetails', 'audit_id', ['alias' => 'details']);
    }

    public function getSource()
    {
        return 'audits';
    }
}
