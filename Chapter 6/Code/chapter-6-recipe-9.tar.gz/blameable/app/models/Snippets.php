<?php

use Phalcon\Mvc\Model;

class Snippets extends Model
{
    public $id;
    public $user_id;
    public $title;
    public $body;
    public $created_at;

    public function initialize()
    {
        $this->belongsTo('user_id', 'Users', 'id', ['alias' => 'user']);
        $this->keepSnapshots(true);
        $this->addBehavior(new Blameable());
    }

    public function getSource()
    {
        return 'snippets';
    }
}
