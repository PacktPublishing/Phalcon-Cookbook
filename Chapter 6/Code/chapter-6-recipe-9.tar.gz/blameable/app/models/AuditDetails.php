<?php

use Phalcon\Mvc\Model;

class AuditDetails extends Model
{
    public $id;
    public $audit_id;
    public $field_name;
    public $old_value;
    public $new_value;

    public function initialize()
    {
        $this->belongsTo('audit_id', 'Audits', 'id', ['alias' => 'audit']);
    }

    public function getSource()
    {
        return 'audit_details';
    }
}
