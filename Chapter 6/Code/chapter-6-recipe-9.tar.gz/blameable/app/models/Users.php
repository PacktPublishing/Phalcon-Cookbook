<?php

use Phalcon\Mvc\Model;

class Users extends Model
{
    public $id;
    public $name;
    public $email;

    public function initialize()
    {
        $this->hasMany('id', 'Snippets', 'user_id', ['alias' => 'snippets']);
    }

    public function getSource()
    {
        return 'users';
    }
}
