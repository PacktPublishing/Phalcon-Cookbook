<?php

use Phalcon\Di;
use Phalcon\Session\Adapter\Libmemcached as MemcachedSession;

$di = new Di();

// Start the session the first time when some
// component request the session service
$di->setShared('session', function () {
    $session = new MemcachedSession([
        'servers' => [
            [
                "host" => "127.0.0.1",
                "port" => 11211
            ]
        ],
        'client' => [],
        'lifetime' => 3600,
        'prefix'   => 'my_'
    ]);

    $session->start();
    return $session;
});

//var_dump(\Memcached::HAVE_SESSION); die;

$data = [
    "abc" => "123",
    "def" => "678",
    "xyz" => "zyx"
];

$sessionID = "abcdef123456";
$session = $di->get('session');
$session->write($sessionID, serialize($data));

var_dump($session->read($sessionID));

$session->destroy($sessionID);