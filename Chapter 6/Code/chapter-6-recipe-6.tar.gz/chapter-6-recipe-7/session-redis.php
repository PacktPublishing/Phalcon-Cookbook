<?php

use Phalcon\Di;
use Phalcon\Session\Adapter\Redis as RedisSession;

$di = new Di();

// Start the session the first time when some
// component request the session service
$di->setShared('session', function () {
    $session = new RedisSession([
        'uniqueId'   => 'my-private-app',
        'host'       => 'localhost',
        'port'       => 6379,
        'persistent' => false,
        'lifetime'   => 3600,
        'prefix'     => 'my_'
    ]);

    $session->start();
    return $session;
});

$data = [
    "abc" => "123",
    "def" => "678",
    "xyz" => "zyx"
];

$sessionID = "abcdef123456";
$session = $di->get('session');
$session->write($sessionID, serialize($data));

var_dump($session->read($sessionID));

$session->destroy($sessionID);