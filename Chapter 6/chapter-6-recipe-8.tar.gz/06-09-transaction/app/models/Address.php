<?php

class Address extends \Phalcon\Mvc\Model
{
    public $id;
    public $users_id;
    public $country;
    public $state;
    public $city;
    public $location;

    public function initialize()
    {
        $this->belongsTo('users_id', 'Users', 'id', ['alias' => 'Users']);
    }

    public function getSource()
    {
        return 'address';
    }
}
