<?php

class Users extends \Phalcon\Mvc\Model
{
    public $id;
    public $name;
    public $email;
    public $password;
    public $active;

    public function initialize()
    {
        $this->hasMany('id', 'Address', 'users_id', ['alias' => 'Address']);
    }

    public function getSource()
    {
        return 'users';
    }
}
