<?php

use Phalcon\Config;

defined('APP_PATH') || define('APP_PATH', realpath('.'));

return new Config([
    'database' => [
        'adapter'     => 'Mysql',
        'host'        => 'localhost',
        'username'    => 'root',
        'password'    => '',
        'dbname'      => 'myapp',
        'charset'     => 'utf8',
    ],
    'application' => [
        'controllersDir' => APP_PATH . '/app/controllers/',
        'modelsDir'      => APP_PATH . '/app/models/',
        'migrationsDir'  => APP_PATH . '/app/migrations/',
        'viewsDir'       => APP_PATH . '/app/views/',
        'pluginsDir'     => APP_PATH . '/app/plugins/',
        'libraryDir'     => APP_PATH . '/app/library/',
        'cacheDir'       => APP_PATH . '/app/cache/',
        'baseUri'        => '/store/',
    ],
    'logs' => [
        'dateFormat' => 'D j H:i:s',
        'format' => '%date%: [%type%] %message%',
        'logsDir' => APP_PATH . '/app/logs/',
    ]
]);
