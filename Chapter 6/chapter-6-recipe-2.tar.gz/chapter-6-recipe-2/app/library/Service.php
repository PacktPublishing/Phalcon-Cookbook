<?php

class Service
{
    public function run($var)
    {
        return debug_backtrace();
    }
}
