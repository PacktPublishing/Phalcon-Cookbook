<?php

class IndexController extends ControllerBase
{
    public function indexAction()
    {
        $this->view->setVar('service_from_controller', $this->myService->run(__CLASS__));
    }
}

