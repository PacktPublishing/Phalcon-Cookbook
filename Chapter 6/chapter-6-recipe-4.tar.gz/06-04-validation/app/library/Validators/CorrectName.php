<?php

namespace MyApp\Validators;

use Phalcon\Validation;
use Phalcon\Validation\Message;
use Phalcon\Validation\Validator;

class CorrectName extends Validator
{
    public function validate(Validation $validator, $attribute)
    {
        $value = $validator->getValue($attribute);
        $pattern = '#^[A-Z][a-z]{2,} [A-Z][a-z]{2,}$#';

        if (!preg_match($pattern, $value)) {
            $message = $this->getOption('message') ?: 'The name is not valid';

            $validator->appendMessage(new Message($message, $attribute, 'CorrectName'));

            return false;
        }

        return true;
    }
}
