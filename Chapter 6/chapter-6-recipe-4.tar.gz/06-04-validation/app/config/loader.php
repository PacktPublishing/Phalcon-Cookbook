<?php

use Phalcon\Loader;

$loader = new Loader();


$loader->registerDirs(
    [
        $config->application->controllersDir,
        $config->application->modelsDir
    ]
);

$loader->registerNamespaces([
    'MyApp\Validators' => $config->application->libraryDir . 'Validators/'
]);


$loader->register();
