<?php

use Phalcon\Validation;
use Phalcon\Validation\Validator\Email as EmailValidator;
use MyApp\Validators\CorrectName as NameValidator;

class Users extends \Phalcon\Mvc\Model
{
    public $id;
    public $name;
    public $email;
    public $password;
    public $active;

    public function getSource()
    {
        return 'users';
    }

    public function validation()
    {
        $validator = new Validation();

        $validator->add(
            'email',
            new EmailValidator()
        );

        $validator->add(
            'name',
            new NameValidator(['message' => 'The user name you entered does not match the required format'])
        );

        return $this->validate($validator);
    }
}
