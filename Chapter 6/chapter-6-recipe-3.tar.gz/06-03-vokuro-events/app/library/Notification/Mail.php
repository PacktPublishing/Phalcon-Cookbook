<?php

namespace Vokuro\Notification;

use Phalcon\Events\Event;
use Phalcon\Di\Injectable;

class Mail
{
    public function afterSaveOnRegister(Event $event, Injectable $source, array $data)
    {
        $adminAddress = "admin@mysite.com";
        $subject      = "Joined new member";
        $template     = "Name: %s, Email: %s, Date: %s\nMessage generated from: %s\nEvent: %s";
        $user         = $data['user'];
        $date         = $data['date'];

        mail(
            $adminAddress,
            $subject,
            sprintf(
                $template,
                $user->name,
                $user->email,
                $date,
                get_class($source),
                $event->getType()
            )
        );

        error_log(sprintf(
            $template,
            $user->name,
            $user->email,
            $date,
            get_class($source),
            $event->getType()
        ));

        return true;
    }
}
