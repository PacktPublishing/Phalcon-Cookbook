<?php
namespace Vokuro\Mail;

class Exception extends \Exception
{
}
