<?php

use Support\Arr;

$array = 'string';

// Get the value from non-array
assert(Arr::path($array, 'foo', 'bar') === 'bar');


$array = [
    'foo' => [
        'bar' => 'baz',
    ]
];

// Get the value of $array['foo']
assert(Arr::path($array, 'foo') === ['bar' => 'baz']);

// Get the value of $array['foo']['bar']
assert(Arr::path($array, 'foo.bar') === 'baz');

$array = [
    'theme' => [
        'phalcomat' => [
            'color' => 'orange'
        ],
        'zyxep' => [
            'color' => 'turquoise'
        ],
    ]
];

$actual = Arr::path($array, 'theme.*');
$expect = ['phalcomat' => ['color' => 'orange'], 'zyxep' => ['color' => 'turquoise']];

// Get the values of "*" in theme
assert($actual === $expect);

$array = [
    'theme' => [
        'button' => [
            'color' => '#f6f3e8',
            'background-color' => '#428bca',
        ],
        'link' => [
            'color' => '#118f9e',
            'background-color' => '#fff',
        ],
    ]
];


$actual = Arr::path($array, 'theme.*.color');
$expect = ['#f6f3e8', '#118f9e'];

// Get the values of "color" in theme
assert($actual === $expect);


// Get the values of "color" in theme
$colors = Arr::path($array, ['theme', '*', 'color']);


var_dump($colors);


var_dump(apc_sma_info());
var_dump(Arr::path(apc_sma_info(), 'block_lists.*.*.size'));
