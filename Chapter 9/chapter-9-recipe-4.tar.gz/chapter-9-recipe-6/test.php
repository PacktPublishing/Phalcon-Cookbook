<?php

use Phalcon\Tag;
use Phalcon\Di\FactoryDefault;
use Phalcon\Cache\Frontend\Output as FrontOutput;
use Phalcon\Cache\Backend\Aerospike as BackAerospike;

include_once 'Aerospike.php';

$di = new FactoryDefault;

// Create an Output frontend. Cache the files for 2 days
$frontCache = new FrontOutput(['lifetime' => 172800]);

$aerospike = new Aerospike(['hosts' => [['addr' => 'aerospike', 'port' => 3000]]]);

// Create the component that will cache from the "Output" to a "Aerospike" backend
$cache = new BackAerospike($frontCache, ['db' => $aerospike]);

// Get/Set the cache file to my-cache-key
$content = $cache->start("some-cache-key");

// If $content is null then the content will be generated for the cache
if (null === $content) {
    // Print date and time
    echo date('r') . "\n";

    // Generate a link to the sign-up action
    echo Tag::linkTo(['user/signup', 'Sign Up', 'class' => 'signup-button']) . "\n";

    // Store the output into the cache file
    $cache->save();
} else {
    // Echo the cached output
    echo $content; 
}