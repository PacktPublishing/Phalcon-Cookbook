<?php

namespace Phalcon\Cache\Backend;

use Phalcon\Cache\Exception;
use Phalcon\Cache\FrontendInterface;
use Phalcon\Cache\Backend;
use Phalcon\Cache\BackendInterface;

class Aerospike extends Backend implements BackendInterface
{
    protected $db;
    protected $namespace = 'test';
    protected $set = 'cache';

    public function __construct(FrontendInterface $frontend, array $options)
    {
        if (!isset($options['db']) || !$options['db'] instanceof \Aerospike) {
            throw new Exception(
                'Parameter "db" is required and it must be an instance of \Aerospike'
            );
        }

        $this->db = $options['db'];

        if (!$this->db->isConnected()) {
            throw new Exception(
                sprintf(
                    'Aerospike failed to connect [%s]: %s',
                    $this->db->errorno(),
                    $this->db->error()
                )
            );
        }

        parent::__construct($frontend, $options);
    }

    public function get($keyName, $lifetime = null)
    {
        $prefixedKey    = $this->_prefix . $keyName;
        $aKey           = $this->buildKey($prefixedKey);
        $this->_lastKey = $prefixedKey;

        $status = $this->db->get($aKey, $cache);

        if ($status != \Aerospike::OK) {
            return null;
        }

        $cachedContent = $cache['bins']['value'];

        if (is_numeric($cachedContent)) {
            return $cachedContent;
        }

        return $this->_frontend->afterRetrieve($cachedContent);
    }

    public function save($keyName = null, $content = null, $lifetime = null, $stopBuffer = true)
    {
        if ($keyName === null) {
            $prefixedKey = $this->_lastKey;
        } else {
            $prefixedKey = $this->_prefix . $keyName;
        }

        if (!$prefixedKey) {
            throw new Exception('The cache must be started first');
        }

        if (null === $content) {
            $cachedContent = $this->_frontend->getContent();
        } else {
            $cachedContent = $content;
        }

        if (null === $lifetime) {
            $lifetime = $this->_lastLifetime;

            if (null === $lifetime) {
                $lifetime = $this->_frontend->getLifetime();
            }
        }

        $aKey = $this->buildKey($prefixedKey);

        if (is_numeric($cachedContent)) {
            $bins = ['value' => $cachedContent];
        } else {
            $bins = ['value' => $this->_frontend->beforeStore($cachedContent)];
        }

        $status = $this->db->put(
            $aKey,
            $bins,
            $lifetime,
            [\Aerospike::OPT_POLICY_KEY => \Aerospike::POLICY_KEY_SEND]
        );

        if (\Aerospike::OK != $status) {
            throw new Exception(
                sprintf('Failed storing data in Aerospike: %s', $this->db->error()),
                $this->db->errorno()
            );
        }

        if (true === $stopBuffer) {
            $this->_frontend->stop();
        }

        if (true === $this->_frontend->isBuffering()) {
            echo $cachedContent;
        }

        $this->_started = false;
    }

    public function delete($keyName)
    {
        $prefixedKey    = $this->_prefix . $keyName;
        $aKey           = $this->buildKey($prefixedKey);
        $this->_lastKey = $prefixedKey;

        $status = $this->db->remove($aKey);

        return $status == \Aerospike::OK;
    }

    public function exists($keyName = null, $lifetime = null)
    {
        if ($keyName === null) {
            $prefixedKey = $this->_lastKey;
        } else {
            $prefixedKey = $this->_prefix . $keyName;
        }

        if (!$prefixedKey) {
            return false;
        }

        $aKey = $this->buildKey($prefixedKey);
        $status = $this->db->get($aKey, $cache);

        return $status == \Aerospike::OK;
    }

    public function queryKeys($prefix = null)
    {
        if (!$prefix) {
            $prefix = $this->_prefix;
        } else {
            $prefix = $this->_prefix . $prefix;
        }

        $keys = [];
        $prefix = $this->_prefix;

        $callback = function ($record) use (&$keys, $prefix, $prefix) {
            $key = $record['key']['key'];

            if (empty($prefix) || 0 === strpos($key, $prefix)) {
                $keys[] = preg_replace(
                    sprintf('#^%s(.+)#u', preg_quote($prefix)),
                    '$1',
                    $key
                );
            }
        };

        $this->db->scan($this->namespace, $this->set, $callback);

        return $keys;
    }

    protected function buildKey($key)
    {
        return $this->db->initKey(
            $this->namespace,
            $this->set,
            $key
        );
    }
}