<?php

class IndexController extends ControllerBase
{

    public function indexAction()
    {
        $cache = $this->di->get('cache');

        var_dump($cache); die;
    }

}

