<?php

use Phalcon\Config;

defined('APP_PATH') || define('APP_PATH', realpath('.'));

return new Config([
    'database' => [
        'adapter'     => 'Mysql',
        'host'        => 'localhost',
        'username'    => 'root',
        'password'    => '',
        'dbname'      => 'test',
        'charset'     => 'utf8',
    ],
    'application' => [
        'controllersDir' => APP_PATH . '/app/controllers/',
        'modelsDir'      => APP_PATH . '/app/models/',
        'migrationsDir'  => APP_PATH . '/app/migrations/',
        'viewsDir'       => APP_PATH . '/app/views/',
        'pluginsDir'     => APP_PATH . '/app/plugins/',
        'libraryDir'     => APP_PATH . '/app/library/',
        'cacheDir'       => APP_PATH . '/app/cache/',
        'baseUri'        => '/',
    ],
    'cache' => [
        'apc' => [
            'prefix'  => 'cache.',
        ],
        'libmemcached' => [
            'servers'  => [
                'host'   => 'localhost',
                'port'   => 11211,
                'weight' => 1,
            ],
            'client' => [
                \Memcached::OPT_HASH => Memcached::HASH_MD5,
                \Memcached::OPT_PREFIX_KEY => 'cache.',
            ],
        ],
        'file' => [
            'prefix'   => 'cache.',
            'cacheDir' => APP_PATH . '/app/cache/',
        ],
    ]
]);
