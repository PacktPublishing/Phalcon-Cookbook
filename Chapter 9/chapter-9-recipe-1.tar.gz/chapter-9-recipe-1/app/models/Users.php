<?php

use Phalcon\Mvc\Model;

class Users extends Model
{
    public function initialize()
    {
        $this->hasMany('id', 'Links', 'user_id', ['alias' => 'links']);
    }
}
