<?php

use Phalcon\Mvc\Model;

class Links extends Model
{
    public function initialize()
    {
        $this->belongsTo('user_id', 'Users', 'id', ['alias' => 'user']);
        $this->hasMany('id', 'Clicks', 'link_id', ['alias' => 'clicks']);
    }
}
