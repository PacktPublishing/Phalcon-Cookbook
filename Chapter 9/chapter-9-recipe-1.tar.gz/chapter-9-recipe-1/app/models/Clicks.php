<?php

use Phalcon\Mvc\Model;

class Clicks extends Model
{
    public function initialize()
    {
        $this->belongsTo('link_id', 'Links', 'id', ['alias' => 'link']);
    }
}
