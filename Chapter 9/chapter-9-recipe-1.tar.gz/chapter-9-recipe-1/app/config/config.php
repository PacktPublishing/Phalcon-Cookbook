<?php

use Phalcon\Config;

defined('APP_PATH') || define('APP_PATH', realpath('.'));

return new Config([
    'database' => [
        'adapter'     => 'Mysql',
        'host'        => '172.17.0.1', // docker host
        'username'    => 'root',
        'password'    => 'secret',
        'dbname'      => 'bqueue',
        'charset'     => 'utf8',
        'port'        => 3307
    ],
    'application' => [
        'controllersDir' => APP_PATH . '/app/controllers/',
        'modelsDir'      => APP_PATH . '/app/models/',
        'migrationsDir'  => APP_PATH . '/app/migrations/',
        'viewsDir'       => APP_PATH . '/app/views/',
        'pluginsDir'     => APP_PATH . '/app/plugins/',
        'libraryDir'     => APP_PATH . '/app/library/',
        'cacheDir'       => APP_PATH . '/app/cache/',
        'baseUri'        => '/',
    ],
    'queue' => [
        'host' => '172.17.0.1', // docker host
        'port' => 11300
    ],
]);
