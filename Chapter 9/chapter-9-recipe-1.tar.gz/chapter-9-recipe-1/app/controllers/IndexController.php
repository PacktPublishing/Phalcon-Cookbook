<?php

class IndexController extends ControllerBase
{
    public function indexAction()
    {
        $code = $this->dispatcher->getParam('code');
        $link = Links::findFirstByShortCode($code);

        /** @var \Phalcon\Queue\Beanstalk $queue */
        $queue = $this->di->getShared('queue');
        $queue->put(['code' => $code, 'click' => date('Y-m-d H:i:s')]);

        return $this->response->redirect($link->long_url, true);
    }
}

