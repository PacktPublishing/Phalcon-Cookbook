--
-- MySQL 5.7 schema
--

CREATE TABLE `users` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(72) DEFAULT NULL,
  `email` VARCHAR(70) DEFAULT NULL,
  `last_ip` INT UNSIGNED DEFAULT NULL,
  `last_visit`  TIMESTAMP DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `users` (`id`, `name`, `email`, `created_at`, `updated_at`) VALUES
  (1, 'John', 'john@doe.com', NOW(), NOW());


CREATE TABLE `links` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT UNSIGNED NOT NULL,
  `long_url` VARCHAR(255) NOT NULL,
  `short_code` VARCHAR(12) NOT NULL,
  `last_visit`  TIMESTAMP DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `link_user_id` (`user_id`),
  KEY `link_short_code` (`short_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `links` (`id`,`user_id`, `long_url`, `short_code`) VALUES
  (688765, 1, 'https://www.igvita.com/2010/05/20/scalable-work-queues-with-beanstalk/', '6wwj'),
  (688766, 1, 'https://docs.phalconphp.com/en/latest/reference/queue.html', '6wwk');


CREATE TABLE `clicks` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `link_id` BIGINT UNSIGNED NOT NULL,
  `click_date` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
