<?php

define('APP_PATH', realpath('..'));

// Read the configuration, auto-loader and services
$config = include APP_PATH . "/app/config/config.php";
include APP_PATH . "/app/config/loader.php";
include APP_PATH . "/app/config/services.php";

$queue = $di->getShared('queue');

while (($job = $queue->peekReady()) !== false) {
    $message = $job->getBody();
    $code    = $message['code'];
    $date    = $message['click'];

    $link = Links::findFirstByShortCode($code);
    $link->last_visit = $date;

    $click = new Clicks();
    $click->click_date = $date;
    $click->link = $link;

    if ($click->save()) {
        echo 'The Click log was successfully updated.', PHP_EOL;
    } else {
        // put here job to the fail_queue
    }

    $job->delete();
}
