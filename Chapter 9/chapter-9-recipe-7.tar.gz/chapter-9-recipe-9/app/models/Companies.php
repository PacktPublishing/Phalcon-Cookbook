<?php

class Companies extends \Phalcon\Mvc\Model
{
    public $id;
    public $name;
    public $telephone;
    public $address;
    public $city;
}
