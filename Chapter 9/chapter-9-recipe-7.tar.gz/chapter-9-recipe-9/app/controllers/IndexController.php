<?php

class IndexController extends ControllerBase
{

    public function indexAction()
    {
        $this->view->setVar(
            'companies',
            Companies::find(
                [
                    'order' => 'id',
                    'cache' => ['key' => 'all-companies'],
                ]
            )
        );
    }

}
