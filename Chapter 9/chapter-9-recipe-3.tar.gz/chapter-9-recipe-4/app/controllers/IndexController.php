<?php

class IndexController extends ControllerBase
{

    public function indexAction()
    {
        $cacheKey = md5(json_encode([__CLASS__, __FUNCTION__, __LINE__]));

        if (!$this->view->getCache()->exists($cacheKey)) {
            sleep(10);
        }

        $this->view->cache([
            'key' => $cacheKey,
            "lifetime" => 12,
        ]);
    }

}

